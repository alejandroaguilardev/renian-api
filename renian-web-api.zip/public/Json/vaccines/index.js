const DOG = require("./dogs.json");
const CAT = require("./cats.json");

const SpeciesVaccines = {
	DOG,
	CAT,
};

module.exports = { SpeciesVaccines };
